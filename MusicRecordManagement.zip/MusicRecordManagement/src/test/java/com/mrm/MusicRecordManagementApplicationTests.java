package com.mrm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MusicRecordManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
