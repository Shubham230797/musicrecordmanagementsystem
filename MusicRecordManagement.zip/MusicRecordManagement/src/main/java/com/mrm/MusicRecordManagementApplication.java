package com.mrm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MusicRecordManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(MusicRecordManagementApplication.class, args);
	}

}
