package com.mrm.util;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.mrm.entities.Singer;
import com.mrm.model.SingerDTO;

@Component
public class SingerConverter {

    // Convert from DTO to Entity
    public Singer convertToSingerEntity(SingerDTO singerDTO) {
        Singer singer = new Singer();
        if (singerDTO != null) {
            BeanUtils.copyProperties(singerDTO, singer);
        }
        return singer;
    }

    // Convert from Entity to DTO
    public SingerDTO convertToSingerDTO(Singer singer) {
        SingerDTO singerDTO = new SingerDTO();
        if (singer != null) {
            BeanUtils.copyProperties(singer, singerDTO);
        }
        return singerDTO;
    }
}
