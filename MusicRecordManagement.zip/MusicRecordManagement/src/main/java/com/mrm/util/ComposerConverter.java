package com.mrm.util;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.mrm.entities.Composer;
import com.mrm.model.ComposerDTO;

@Component
public class ComposerConverter {

    // Convert from DTO to Entity
    public Composer convertToComposerEntity(ComposerDTO composerDTO) {
        Composer composer = new Composer();
        if (composerDTO != null) {
            BeanUtils.copyProperties(composerDTO, composer);
        }
        return composer;
    }

    // Convert from Entity to DTO
    public ComposerDTO convertToComposerDTO(Composer composer) {
        ComposerDTO composerDTO = new ComposerDTO();
        if (composer != null) {
            BeanUtils.copyProperties(composer, composerDTO);
        }
        return composerDTO;
    }
}
