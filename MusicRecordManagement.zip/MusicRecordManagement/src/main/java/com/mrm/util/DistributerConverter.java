package com.mrm.util;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.mrm.entities.Distributer;
import com.mrm.model.DistributerDTO;

@Component
public class DistributerConverter {

    // Convert from DTO to Entity
    public Distributer convertToDistributerEntity(DistributerDTO distributerDTO) {
        Distributer distributer = new Distributer();
        if (distributerDTO != null) {
            BeanUtils.copyProperties(distributerDTO, distributer);
        }
        return distributer;
    }

    // Convert from Entity to DTO
    public DistributerDTO convertToDistributerDTO(Distributer distributer) {
        DistributerDTO distributerDTO = new DistributerDTO();
        if (distributer != null) {
            BeanUtils.copyProperties(distributer, distributerDTO);
        }
        return distributerDTO;
    }
}
