package com.mrm.service;

import java.util.List;

import com.mrm.entities.Distributer;
import com.mrm.model.DistributerDTO;

public interface DistributerService {
    DistributerDTO createDistributer(Distributer distributer);
    List<DistributerDTO> getAllDistributers();
    DistributerDTO getDistributerById(int id);
    DistributerDTO updateDistributer(int id, Distributer distributer);
    String deleteDistributer(int id);
}
