package com.mrm.service;

import java.util.List;

import com.mrm.entities.Singer;
import com.mrm.model.SingerDTO;

public interface SingerService {
    SingerDTO createSinger(Singer singer);
    List<SingerDTO> getAllSingers();
    SingerDTO getSingerById(int id);
    SingerDTO updateSinger(int id, Singer singer);
    String deleteSinger(int id);
}
