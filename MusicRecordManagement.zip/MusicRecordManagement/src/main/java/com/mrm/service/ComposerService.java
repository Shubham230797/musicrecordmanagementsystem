package com.mrm.service;

import java.util.List;

import com.mrm.entities.Composer;
import com.mrm.model.ComposerDTO;

public interface ComposerService {
    ComposerDTO createComposer(Composer composer);
    List<ComposerDTO> getAllComposers();
    ComposerDTO getComposerById(int id);
    ComposerDTO updateComposer(int id, Composer composer);
    String deleteComposer(int id);
    String addSingerToComposer(int tid,int sid);
  //  ComposerDTO addSingerToComposer(int composerId, int singerId);
    
}
