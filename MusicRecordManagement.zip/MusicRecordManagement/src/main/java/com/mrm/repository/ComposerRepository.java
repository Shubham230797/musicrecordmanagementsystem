package com.mrm.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.mrm.entities.Composer;

public interface ComposerRepository extends JpaRepository<Composer, Integer>{

}
