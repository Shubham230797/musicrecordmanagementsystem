package com.mrm.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mrm.entities.Singer;

public interface SingerRepository extends JpaRepository<Singer, Integer>{

}
