package com.mrm.entities;

import java.util.Set;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Singer {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int sid;

    @Column(length = 50)
    private String sname;

    @Column(length = 100)
    private String sadd;

    @Column(unique = true)
    private String sph;

    private boolean status = Boolean.TRUE;

  /*  @ManyToMany(mappedBy = "singers")
    private Set<Composer> composers;*/
    
    @ManyToOne(cascade = CascadeType.PERSIST)
    @JoinColumn(name = "composerId") // Specify the appropriate column name
    @JsonIgnoreProperties("singers") // Update this with the correct property name in Composer class
    private Composer composer;

}

