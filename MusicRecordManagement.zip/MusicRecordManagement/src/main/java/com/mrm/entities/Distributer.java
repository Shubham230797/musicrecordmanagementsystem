package com.mrm.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Distributer {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int did;
	
	@Column(length=50)
	private String dname;
	
	@Column(length=100)
	private String dadd;
	
	@Column(unique = true)
	private String dph;
	
	private boolean status = Boolean.TRUE;
	
	 
}
