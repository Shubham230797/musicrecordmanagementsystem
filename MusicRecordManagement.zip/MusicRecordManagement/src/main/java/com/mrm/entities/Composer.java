package com.mrm.entities;

import java.util.List;
import java.util.Set;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Composer {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int cid;

    @Column(length = 50)
    private String cname;

    @Column(length = 100)
    private String cadd;

    @Column(unique = true)
    private String cph;

    private boolean status = Boolean.TRUE;
    
   /* @ManyToMany
    @JoinTable(
        name = "composer_singer",
        joinColumns = @JoinColumn(name = "composer_id"),
        inverseJoinColumns = @JoinColumn(name = "singer_id"))
        private Set<Singer> singers; */
    
    @OneToMany(mappedBy = "composer", cascade = CascadeType.PERSIST)
    @JsonIgnoreProperties("composer")
    private List<Singer> singers;

}

