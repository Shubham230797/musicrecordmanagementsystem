package com.mrm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.mrm.entities.Distributer;
import com.mrm.model.DistributerDTO;
import com.mrm.service.DistributerService;
import com.mrm.util.DistributerConverter;

@RestController
@RequestMapping("/api")
public class DistributerController {

    @Autowired
    private DistributerService distributerService;

    @Autowired
    private DistributerConverter distributerConverter;

    @PostMapping("/createDistributer")
    ResponseEntity<DistributerDTO> createDistributer(@RequestBody DistributerDTO distributerDTO) {
        final Distributer distributer = distributerConverter.convertToDistributerEntity(distributerDTO);
        return new ResponseEntity<>(distributerService.createDistributer(distributer), HttpStatus.CREATED);
    }

    @GetMapping("/getAllDistributers")
    List<DistributerDTO> getAllDistributers() {
        return distributerService.getAllDistributers();
    }

    @GetMapping("/getDistributerById/{id}")
    DistributerDTO getDistributerById(@PathVariable("id") int id) {
        return distributerService.getDistributerById(id);
    }

    @PutMapping("/updateDistributer/{id}")
    DistributerDTO updateDistributer(@PathVariable int id, @RequestBody DistributerDTO distributerDTO) {
        final Distributer distributer = distributerConverter.convertToDistributerEntity(distributerDTO);
        return distributerService.updateDistributer(id, distributer);
    }

    @DeleteMapping("/deleteDistributer/{id}")
    String deleteDistributer(@PathVariable int id) {
        return distributerService.deleteDistributer(id);
    }
}
