package com.mrm.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mrm.entities.Composer;
import com.mrm.model.ComposerDTO;
import com.mrm.service.ComposerService;
import com.mrm.util.ComposerConverter;



@RestController
@RequestMapping("/api")
public class ComposerController {

    @Autowired
    private ComposerService composerService;

    @Autowired
    private ComposerConverter composerConverter;


    @PostMapping("/createComposer")
    ResponseEntity<ComposerDTO> createComposer(@RequestBody ComposerDTO composerDTO) {
        final Composer composer = composerConverter.convertToComposerEntity(composerDTO);
   
        return new ResponseEntity<>(composerService.createComposer(composer), HttpStatus.CREATED);
    }

    @GetMapping("/getAllComposers")
    List<ComposerDTO> getAllComposers() {
        return composerService.getAllComposers();
    }

    @GetMapping("/getComposerById/{id}")
    ComposerDTO getComposerById(@PathVariable("id") int id) {
        return composerService.getComposerById(id);
    }

    @PutMapping("/updateComposer/{id}")
    ComposerDTO updateComposer(@PathVariable int id, @RequestBody ComposerDTO composerDTO) {
        final Composer composer = composerConverter.convertToComposerEntity(composerDTO);
        return composerService.updateComposer(id, composer);
    }
    
  /*  @PostMapping("/addSingerToComposer/{composerId}/{singerId}")
    ResponseEntity<ComposerDTO> addSingerToComposer( @PathVariable int composerId,@PathVariable int singerId) {
    			
     return new ResponseEntity<ComposerDTO>(composerService.addSingerToComposer(composerId, singerId),HttpStatus.OK);
    }*/
    
    @PostMapping("/addSingerToCOmposer/{sid}/{cid}")
	public String assignStudentToTeacher(@PathVariable("sid") int sid,
			@PathVariable("cid") int cid)
	{
		return composerService.addSingerToComposer(sid, cid);
	}
    
    


    @DeleteMapping("/deleteComposer/{id}")
    String deleteComposer(@PathVariable int id) {
        return composerService.deleteComposer(id);
    }
}

