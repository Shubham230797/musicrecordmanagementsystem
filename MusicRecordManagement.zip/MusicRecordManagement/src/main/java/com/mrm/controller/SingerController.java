package com.mrm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.mrm.entities.Singer;
import com.mrm.model.SingerDTO;
import com.mrm.service.SingerService;
import com.mrm.util.SingerConverter;

@RestController
@RequestMapping("/api")
public class SingerController {

    @Autowired
    private SingerService singerService;

    @Autowired
    private SingerConverter singerConverter;

    @PostMapping("/createSinger")
    ResponseEntity<SingerDTO> createSinger(@RequestBody SingerDTO singerDTO) {
        final Singer singer = singerConverter.convertToSingerEntity(singerDTO);
        return new ResponseEntity<>(singerService.createSinger(singer), HttpStatus.CREATED);
    }

    @GetMapping("/getAllSingers")
    List<SingerDTO> getAllSingers() {
        return singerService.getAllSingers();
    }

    @GetMapping("/getSingerById/{id}")
    SingerDTO getSingerById(@PathVariable("id") int id) {
        return singerService.getSingerById(id);
    }

    @PutMapping("/updateSinger/{id}")
    SingerDTO updateSinger(@PathVariable int id, @RequestBody SingerDTO singerDTO) {
        final Singer singer = singerConverter.convertToSingerEntity(singerDTO);
        return singerService.updateSinger(id, singer);
    }

    @DeleteMapping("/deleteSinger/{id}")
    String deleteSinger(@PathVariable int id) {
        return singerService.deleteSinger(id);
    }
}
