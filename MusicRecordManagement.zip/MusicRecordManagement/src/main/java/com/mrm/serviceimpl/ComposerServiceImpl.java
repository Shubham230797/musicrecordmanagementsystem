package com.mrm.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import com.mrm.exception.ResourceNotFoundException;
import org.springframework.stereotype.Service;
import com.mrm.entities.Composer;
import com.mrm.entities.Singer;
import com.mrm.model.ComposerDTO;
import com.mrm.repository.ComposerRepository;
import com.mrm.repository.SingerRepository;
import com.mrm.service.ComposerService;
import com.mrm.util.ComposerConverter;
import com.mrm.entities.Singer;
import com.mrm.entities.Composer;
import com.mrm.exception.ResourceNotFoundException;

import java.util.ArrayList;
import java.util.List;

@Service
public class ComposerServiceImpl implements ComposerService {

    @Autowired
    private ComposerRepository composerRepository;

    @Autowired
    private ComposerConverter composerConverter;
    
    @Autowired
    private SingerRepository singerRepository;
    
    @Override
    public ComposerDTO createComposer(Composer composer) {
        Composer savedComposer = composerRepository.save(composer);
        return composerConverter.convertToComposerDTO(savedComposer);
    }

    @Override
    public List<ComposerDTO> getAllComposers() {
        List<Composer> composers = composerRepository.findAll();

        // list of type DTO
        List<ComposerDTO> dtoList = new ArrayList<>();
        for (Composer c : composers) {
            dtoList.add(composerConverter.convertToComposerDTO(c));
        }

        return dtoList;
    }

    @Override
    public ComposerDTO getComposerById(int id) {
        Composer composer = composerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Composer not found with id: " + id));
        return composerConverter.convertToComposerDTO(composer);
    }
    
  /*  @Override
    public ComposerDTO addSingerToComposer(int composerId, int singerId) {
        Composer composer = composerRepository.findById(composerId).orElse(null);
        Singer singer = singerRepository.findById(singerId).orElse(null);

        if (composer != null && singer != null) {
            composer.getSingers().add(singer);
            singer.getComposers().add(composer);

            // Save the changes
            composerRepository.save(composer);
            singerRepository.save(singer);

            return composerConverter.convertToComposerDTO(composer);
        } else {
            // Handle case where composer or singer is not found
            return null;
        }
    }*/
    
    @Override
	public String addSingerToComposer(int tid, int sid) {
		Singer s=singerRepository.findById(sid).orElseThrow(()->
		new ResourceNotFoundException("Singer", "Id", sid));
		
		Composer  t=composerRepository.findById(tid).orElseThrow(()->
		new ResourceNotFoundException("Composer", "Id", tid));
		
		List<Singer> students=new ArrayList<>();
		students.add(s);
		
		//assign students to teacher
		t.setSingers(students);
		
		//assign teacher to student
		s.setComposer(t);
		
		composerRepository.save(t);
		return "Singer add to composer successfully";
	}
 
    
    @Override
    public ComposerDTO updateComposer(int id, Composer composer) {
        Composer c = composerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Composer not found with id: " + id));

        // Update composer fields based on your requirements
        c.setCname(composer.getCname());
        c.setCadd(composer.getCadd());
        c.setCph(composer.getCph());

        Composer updatedComposer = composerRepository.save(c);
        return composerConverter.convertToComposerDTO(updatedComposer);
    }

    
    
    @Override
    public String deleteComposer(int id) {
        if (composerRepository.existsById(id)) {
            composerRepository.deleteById(id);
            return "Composer deleted successfully!";
        } else {
            return "Composer not found with id: " + id;
        }
    }
}

