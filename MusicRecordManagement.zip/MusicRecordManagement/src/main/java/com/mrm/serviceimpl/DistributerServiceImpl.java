package com.mrm.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mrm.entities.Distributer;
import com.mrm.model.DistributerDTO;
import com.mrm.repository.DistributerRepository;
import com.mrm.service.DistributerService;
import com.mrm.util.DistributerConverter;

import java.util.ArrayList;
import java.util.List;

@Service
public class DistributerServiceImpl implements DistributerService {

    @Autowired
    private DistributerRepository distributerRepository;

    @Autowired
    private DistributerConverter distributerConverter;

    @Override
    public DistributerDTO createDistributer(Distributer distributer) {
        Distributer savedDistributer = distributerRepository.save(distributer);
        return distributerConverter.convertToDistributerDTO(savedDistributer);
    }

    @Override
    public List<DistributerDTO> getAllDistributers() {
        List<Distributer> distributers = distributerRepository.findAll();

        List<DistributerDTO> dtoList = new ArrayList<>();
        for (Distributer d : distributers) {
            dtoList.add(distributerConverter.convertToDistributerDTO(d));
        }

        return dtoList;
    }

    @Override
    public DistributerDTO getDistributerById(int id) {
        Distributer distributer = distributerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Distributer not found with id: " + id));
        return distributerConverter.convertToDistributerDTO(distributer);
    }

  /*  @Override
    public DistributerDTO updateDistributer(int id, Distributer distributer) {
        Distributer d = distributerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Distributer not found with id: " + id));

        // Update distributer fields based on your requirements
        // d.setName(distributer.getName());
        // d.setSomeOtherField(distributer.getSomeOtherField());

        Distributer updatedDistributer = distributerRepository.save(d);
        return distributerConverter.convertToDistributerDTO(updatedDistributer);
    }*/
    
    @Override
    public DistributerDTO updateDistributer(int id, Distributer distributer) {
        Distributer d = distributerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Distributer not found with id: " + id));

        // Update distributer fields based on your requirements
        d.setDname(distributer.getDname());
        d.setDadd(distributer.getDadd());
        d.setDph(distributer.getDph());

        Distributer updatedDistributer = distributerRepository.save(d);
        return distributerConverter.convertToDistributerDTO(updatedDistributer);
    }


    @Override
    public String deleteDistributer(int id) {
        if (distributerRepository.existsById(id)) {
            distributerRepository.deleteById(id);
            return "Distributer deleted successfully!";
        } else {
            return "Distributer not found with id: " + id;
        }
    }
}
