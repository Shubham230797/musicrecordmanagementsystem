package com.mrm.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mrm.entities.Singer;
import com.mrm.model.SingerDTO;
import com.mrm.repository.SingerRepository;
import com.mrm.service.SingerService;
import com.mrm.util.SingerConverter;

import java.util.ArrayList;
import java.util.List;

@Service
public class SingerServiceImpl implements SingerService {

    @Autowired
    private SingerRepository singerRepository;

    @Autowired
    private SingerConverter singerConverter;

    @Override
    public SingerDTO createSinger(Singer singer) {
        Singer savedSinger = singerRepository.save(singer);
        return singerConverter.convertToSingerDTO(savedSinger);
    }

    @Override
    public List<SingerDTO> getAllSingers() {
        List<Singer> singers = singerRepository.findAll();

        List<SingerDTO> dtoList = new ArrayList<>();
        for (Singer s : singers) {
            dtoList.add(singerConverter.convertToSingerDTO(s));
        }

        return dtoList;
    }

    @Override
    public SingerDTO getSingerById(int id) {
        Singer singer = singerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Singer not found with id: " + id));
        return singerConverter.convertToSingerDTO(singer);
    }

    /*@Override
    public SingerDTO updateSinger(int id, Singer singer) {
        Singer s = singerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Singer not found with id: " + id));

        // Update singer fields based on your requirements
        // s.setName(singer.getName());
        // s.setSomeOtherField(singer.getSomeOtherField());

        Singer updatedSinger = singerRepository.save(s);
        return singerConverter.convertToSingerDTO(updatedSinger);
    }*/
    
    @Override
    public SingerDTO updateSinger(int id, Singer singer) {
        Singer s = singerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Singer not found with id: " + id));

        // Update singer fields based on your requirements
        s.setSname(singer.getSname());
        s.setSadd(singer.getSadd());
        s.setSph(singer.getSph());

        Singer updatedSinger = singerRepository.save(s);
        return singerConverter.convertToSingerDTO(updatedSinger);
    }


    @Override
    public String deleteSinger(int id) {
        if (singerRepository.existsById(id)) {
            singerRepository.deleteById(id);
            return "Singer deleted successfully!";
        } else {
            return "Singer not found with id: " + id;
        }
    }
}
