package com.mrm.model;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ComposerDTO {

	private int cid;
	private String cname;
	private String cadd;
	private String cph;
	
	private List<SingerDTO> singers;
	
}

