package com.mrm.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class DistributerDTO {

	private int did;
	private String dname;
	private String dadd;
	private String dph;
}
